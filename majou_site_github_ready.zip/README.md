# Võ Thị Trang Hân – Má Jou

🌸 Chào mừng bạn đến với trang web cá nhân của tôi – nơi lưu giữ những bài du ký, tản văn và ghi chép đời sống.

## ✍️ Nội dung trên web
- **Du ký**: Hành trình qua nhiều vùng đất, từ biển xa Maldives đến thảo nguyên Mông Cổ.
- **Tản văn**: Chút nhẹ nhàng, chút hài hước, chút triết lý từ chuyện đời thường.
- **Ghi chép**: Những khoảnh khắc và chi tiết đời sống, được viết lại như chính tôi cảm nhận.

## 🛠 Công nghệ
Trang web được xây dựng bằng **Hugo** và triển khai trên **Netlify**.

## 🌐 Xem web
[https://vo-thi-trang-han.netlify.app](https://vo-thi-trang-han.netlify.app)

---
*“Có đến mới biết, có biết mới hiểu, có hiểu mới thương, có thương mới mở lòng.”*
